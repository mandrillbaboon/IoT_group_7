# EnviroSense

A self-hosted IoT monitoring dashboard for ESP8266 temperature/humidity sensors.

## Architecture

- Flask web dashboard on port **6007**
- MQTT broker (Mosquitto) on port **1883**
- ESP8266 nodes publish DHT11 readings every 5 seconds
- Data is stored in SQLite and visualized on the dashboard

## Try it

```
http://<host>:6007
```

Register an account to view the live data feed.

## Status

In active development. Currently deployed: 1 sensor node.
