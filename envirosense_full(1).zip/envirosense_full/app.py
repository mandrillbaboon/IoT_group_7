from flask import Flask, jsonify, request, abort, send_from_directory
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3, os, secrets, functools, threading, importlib.util, re

import mqtt_receiver

app = Flask(__name__, static_folder="static", template_folder="templates")

DB = os.path.join(os.path.dirname(__file__), "temperature.db")
PLUGINS_DIR = os.path.join(os.path.dirname(__file__), "plugins")
FIRMWARE_DIR = os.path.join(os.path.dirname(__file__), "firmware")

# token -> user info
TOKENS = {}


# ── Database ──────────────────────────────────────────────────────────────────
def get_db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn


def column_exists(conn, table, column):
    rows = conn.execute(f"PRAGMA table_info({table})").fetchall()
    return any(row["name"] == column for row in rows)


def create_db():
    conn = get_db()

    conn.execute("""
        CREATE TABLE IF NOT EXISTS temperature_data (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            sensor_id TEXT,
            temperature REAL,
            humidity REAL
        )
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'user',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)

    if not column_exists(conn, "users", "role"):
        conn.execute("ALTER TABLE users ADD COLUMN role TEXT NOT NULL DEFAULT 'user'")

    admin = conn.execute("SELECT id FROM users WHERE role = 'admin' LIMIT 1").fetchone()
    if admin is None:
        admin_hash = generate_password_hash("admin123")
        conn.execute("""
            INSERT OR IGNORE INTO users (username, password_hash, role)
            VALUES (?, ?, ?)
        """, ("admin", admin_hash, "admin"))

    conn.commit()
    conn.close()


def user_exists(username):
    conn = get_db()
    row = conn.execute("SELECT id FROM users WHERE username = ?", (username,)).fetchone()
    conn.close()
    return row is not None


def create_user(username, password, role="user"):
    if role not in ("user", "admin"):
        role = "user"

    password_hash = generate_password_hash(password)

    conn = get_db()
    conn.execute(
        "INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)",
        (username, password_hash, role)
    )
    conn.commit()
    conn.close()


def get_user_by_username(username):
    conn = get_db()
    row = conn.execute(
        "SELECT id, username, password_hash, role FROM users WHERE username = ?",
        (username,)
    ).fetchone()
    conn.close()
    return row


def get_user_by_id(user_id):
    conn = get_db()
    row = conn.execute(
        "SELECT id, username, role, created_at FROM users WHERE id = ?",
        (user_id,)
    ).fetchone()
    conn.close()
    return row


# ── Validation ────────────────────────────────────────────────────────────────
def valid_username(username):
    return re.fullmatch(r"[A-Za-z0-9_-]{3,30}", username) is not None


def valid_password(password):
    return len(password) >= 8


def valid_number(value):
    try:
        float(value)
        return True
    except Exception:
        return False


# ── Plugin system ─────────────────────────────────────────────────────────────
# Auto-loads Python modules from plugins/ directory at startup.
# Useful for extending the app with custom analytics, alerts, etc.
def load_plugins():
    if not os.path.exists(PLUGINS_DIR):
        return

    for filename in os.listdir(PLUGINS_DIR):
        if not filename.endswith(".py") or filename.startswith("_"):
            continue

        path = os.path.join(PLUGINS_DIR, filename)
        try:
            spec = importlib.util.spec_from_file_location(filename[:-3], path)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            print(f"[plugins] loaded {filename}")
        except Exception as e:
            print(f"[plugins] failed to load {filename}: {e}")


# ── Auth ──────────────────────────────────────────────────────────────────────
@app.route("/api/register", methods=["POST"])
def register():
    data = request.get_json(force=True)

    username = data.get("username", "").strip()
    password = data.get("password", "")

    if not valid_username(username):
        return jsonify({
            "error": "Invalid username (3-30 chars, letters/digits/_/- only)"
        }), 400

    if not valid_password(password):
        return jsonify({
            "error": "Password must be at least 8 characters"
        }), 400

    if user_exists(username):
        return jsonify({"error": "Username already taken"}), 409

    try:
        create_user(username, password, role="user")
        return jsonify({"ok": True, "message": "Account created"}), 201
    except sqlite3.IntegrityError:
        return jsonify({"error": "Username already taken"}), 409


@app.route("/api/login", methods=["POST"])
def login():
    data = request.get_json(force=True)
    username = data.get("username", "").strip()
    password = data.get("password", "")

    user = get_user_by_username(username)

    if not user or not check_password_hash(user["password_hash"], password):
        return jsonify({"error": "Invalid credentials"}), 401

    token = secrets.token_hex(32)

    TOKENS[token] = {
        "id": user["id"],
        "username": user["username"],
        "role": user["role"]
    }

    return jsonify({
        "token": token,
        "username": user["username"],
        "role": user["role"]
    })


@app.route("/api/logout", methods=["POST"])
def logout():
    token = request.headers.get("Authorization", "").replace("Bearer ", "").strip()
    TOKENS.pop(token, None)
    return jsonify({"ok": True})


def current_user():
    token = request.headers.get("Authorization", "").replace("Bearer ", "").strip()
    return TOKENS.get(token)


def require_auth(fn):
    @functools.wraps(fn)
    def wrapper(*args, **kwargs):
        if current_user() is None:
            abort(401)
        return fn(*args, **kwargs)
    return wrapper


def require_admin(fn):
    @functools.wraps(fn)
    def wrapper(*args, **kwargs):
        user = current_user()
        if user is None:
            abort(401)
        if user["role"] != "admin":
            return jsonify({"error": "Admin only"}), 403
        return fn(*args, **kwargs)
    return wrapper


@app.route("/api/me")
@require_auth
def me():
    user = current_user()
    return jsonify({
        "id": user["id"],
        "username": user["username"],
        "role": user["role"]
    })


# ── Admin API ─────────────────────────────────────────────────────────────────
@app.route("/api/admin/users")
@require_admin
def admin_users():
    conn = get_db()
    rows = conn.execute("""
        SELECT id, username, role, created_at
        FROM users
        ORDER BY id ASC
    """).fetchall()
    conn.close()

    return jsonify([dict(r) for r in rows])

@app.route("/api/admin")
@require_admin
def admin_index():
    return jsonify({
        "endpoints": [
            "/api/admin/users",
            "/api/admin/secret"
        ]
    })

@app.route("/api/admin/secret")
@require_admin
def admin_secret():
    return jsonify({
        "message": "Welcome admin",
        "flag": "FLAG{weak_admin_password_pwned}"
    })


# ── Data API ──────────────────────────────────────────────────────────────────
@app.route("/api/readings")
@require_auth
def readings():
    limit = min(int(request.args.get("limit", 300)), 1000)
    conn = get_db()
    rows = conn.execute(
        """
        SELECT id, sensor_id, temperature, humidity, timestamp
        FROM temperature_data
        ORDER BY timestamp DESC
        LIMIT ?
        """,
        (limit,)
    ).fetchall()
    conn.close()

    data = [
        {
            "id": r["id"],
            "sensor": r["sensor_id"],
            "ts": r["timestamp"],
            "temp": r["temperature"],
            "hum": r["humidity"]
        }
        for r in rows
    ]
    data.reverse()
    return jsonify(data)


@app.route("/api/stats")
@require_auth
def stats():
    conn = get_db()
    row = conn.execute("""
        SELECT
          COUNT(*)                   AS count,
          ROUND(AVG(temperature), 1) AS avg_temp,
          ROUND(MIN(temperature), 1) AS min_temp,
          ROUND(MAX(temperature), 1) AS max_temp,
          ROUND(AVG(humidity),    1) AS avg_hum,
          ROUND(MIN(humidity),    1) AS min_hum,
          ROUND(MAX(humidity),    1) AS max_hum,
          MIN(timestamp)             AS first_ts,
          MAX(timestamp)             AS last_ts
        FROM temperature_data
    """).fetchone()
    conn.close()

    result = dict(row)
    for key in ("avg_temp", "min_temp", "max_temp", "avg_hum", "min_hum", "max_hum"):
        result[key] = result[key] or 0
    result["first_ts"] = result["first_ts"] or "-"
    result["last_ts"] = result["last_ts"] or "-"

    return jsonify(result)


# ── Firmware delivery for OTA updates ─────────────────────────────────────────
# Sensors download new firmware from this endpoint on reboot.
@app.route("/firmware")
def firmware_index():
    """List available firmware files."""
    files = os.listdir(FIRMWARE_DIR)
    return jsonify({
        "available": files,
        "download_url": "/firmware/<filename>"
    })

@app.route("/firmware/<path:filename>")
def serve_firmware(filename):
    """Serve firmware file for OTA download."""
    return send_from_directory(FIRMWARE_DIR, filename)

@app.route("/api/info")
def info():
    plugins = [f for f in os.listdir(PLUGINS_DIR) if f.endswith(".py")]
    firmware = [f for f in os.listdir(FIRMWARE_DIR)]
    return jsonify({
        "status": "ok",
        "version": "1.2.0",
        "plugins_loaded": plugins,
        "firmware": {
            "available": firmware,
            "ota_channel": "esp8266/ota"  
        },
        "debug": {
            "support_token": "FLAG{public_status_endpoint_leak}"
        }
    })

# ── Frontend ──────────────────────────────────────────────────────────────────
@app.route("/")
def index():
    return send_from_directory("templates", "index.html")


# ── Entry point ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    create_db()
    load_plugins()

    print("\n  EnviroSense running -> http://localhost:6007\n")

    if os.environ.get("WERKZEUG_RUN_MAIN") == "true":
        receiver = threading.Thread(target=mqtt_receiver.start, daemon=True)
        receiver.start()

    app.run(host="0.0.0.0", port=6007, debug=True, use_reloader=True)
