"""
Simulates an ESP8266 sensor publishing temperature/humidity readings.
Use this instead of a real ESP8266 when developing locally.

Run: python sensor_simulator.py
"""
import json
import time
import random
import os
from paho.mqtt import client as mqtt_client

BROKER = os.environ.get("MQTT_BROKER", "localhost")
PORT = int(os.environ.get("MQTT_PORT", "1883"))

MQTT_USER = os.environ.get("MQTT_USER", "iot_device")
MQTT_PASS = os.environ.get("MQTT_PASS", "iot2024")

SENSOR_ID = 6
DATA_TOPIC = "esp8266/dht11"
STATUS_TOPIC = f"esp8266/status/sensor{SENSOR_ID}"


def main():
    client = mqtt_client.Client(client_id=f"esp8266-sim-{SENSOR_ID}")
    client.username_pw_set(MQTT_USER, MQTT_PASS)
    client.connect(BROKER, PORT, 60)
    client.loop_start()

    # Publish status with firmware/ota info (mimics real ESP8266 boot announce)
    status = {
        "sensor_id": SENSOR_ID,
        "firmware": "v1.2",
        "ota_topic": "esp8266/ota",
        "uptime": 0
    }
    client.publish(STATUS_TOPIC, json.dumps(status), retain=True)
    print(f"[sim] status published on {STATUS_TOPIC}")

    temp = 22.0
    hum = 55.0
    counter = 0

    while True:
        counter += 1

        temp += random.uniform(-0.3, 0.3)
        hum += random.uniform(-0.5, 0.5)
        temp = max(15.0, min(30.0, temp))
        hum = max(30.0, min(80.0, hum))

        payload = {
            "sensor_id": SENSOR_ID,
            "temperature": round(temp, 1),
            "humidity": round(hum, 1)
        }

        if counter % 5 == 0:
            payload["maintenance_token"] = "FLAG{mqtt_sensor_payload_leak}"

        client.publish(DATA_TOPIC, json.dumps(payload))
        print(f"[sim] -> {payload}")
        time.sleep(5)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n[sim] bye")
