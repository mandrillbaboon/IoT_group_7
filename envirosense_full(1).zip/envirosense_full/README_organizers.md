# EnviroSense — CTF Edition

A deliberately vulnerable IoT monitoring app for a CTF challenge.

> ⚠️ Do **not** expose this on the public internet. Run it in a lab/VLAN.

## Stack

- **Flask** web app + REST API (port 6007)
- **SQLite** for persistence
- **Mosquitto** MQTT broker (port 1883)
- ESP8266 sensors — either real, or simulated by `sensor_simulator.py`

## Quick start (no Raspberry Pi needed)

```bash
# 1. install python deps
pip install -r requirements.txt

# 2. start mosquitto (Docker is easiest)
docker compose up -d

# 3. start the Flask app (in one terminal)
python app.py

# 4. start the fake sensor (in another terminal)
python sensor_simulator.py
```

Visit http://localhost:6007.

Default users:
- `admin` / `admin123` (admin) — only known to organizers
- Register your own with the UI for a regular `user`

## The challenge (organizer notes — DO NOT SHARE WITH ATTACKERS)

There are three flags hidden in this app, each behind a different bug.

### FLAG 1 — `FLAG{weak_admin_password_pwned}`

- **Endpoint:** `GET /api/admin/secret`
- **How:** brute force / guess the admin password. It is `admin123`, in any
  reasonable wordlist (`rockyou`, default credential lists, etc.).
- **Difficulty:** 🟢 warm-up

### FLAG 2 — discovery of the OTA topic

- **How:** subscribe to `#` on MQTT after cracking MQTT credentials
  (`iot_device:iot2024` — also in default-credential wordlists).
- The `sensor_simulator.py` publishes a retained message on
  `esp8266/status/sensor6` containing `"ota_topic": "esp8266/ota"`.
- Confirming the topic works: publish a JSON `{"name":"x.bin","data":"..."}`
  and see the file appear at `GET /firmware/x.bin`.
- **Not really a flag** — this is the breadcrumb to FLAG 3.

### FLAG 3 — `FLAG{ota_path_traversal_to_rce_chain}`

- The OTA handler in `mqtt_receiver.py::handle_ota()` does:
  ```python
  path = os.path.join(FIRMWARE_DIR, name)
  ```
  with `name` coming straight from the MQTT payload. `os.path.join` does
  **not** prevent `..`, so an attacker can write outside `firmware/`.
- `app.py` has a `load_plugins()` system that auto-imports every `.py` in
  `plugins/` on startup.
- `app.py` runs with `debug=True` + `use_reloader=True`, so adding a new
  `.py` file anywhere in the project tree triggers a reload, which calls
  `load_plugins()` again, which executes the attacker's code.
- The attacker uploads a payload with `"name": "../plugins/pwn.py"` and
  RCE happens automatically within ~1 second.
- The payload reads `.env`, which contains `ADMIN_RECOVERY_KEY=FLAG{...}`.

### Attack chain summary

```
nmap → port 1883 + 6007 open
  ↓
brute force MQTT (iot_device:iot2024)
  ↓
mosquitto_sub -t '#'  → discover esp8266/status with ota_topic hint
  ↓
publish to esp8266/ota with {"name":"test.bin","data":"<b64>"}
  → confirm file appears at /firmware/test.bin
  ↓
path traversal: {"name":"../plugins/pwn.py","data":"<b64 payload>"}
  → Flask reloader picks up new .py
  → load_plugins() re-executes
  → RCE
  ↓
read .env → FLAG{ota_path_traversal_to_rce_chain}
```

## Why this design is "fair"

Every primitive in the chain is a **realistic mistake** a junior dev might
make on a hobby IoT project:

- Weak MQTT password "because it's just sensors on a LAN"
- Retained status messages with internal config "for debugging"
- `os.path.join` without sanitization "because we control the input"
- `debug=True` "we'll turn it off before deploying"
- Plugin auto-loader "for extensibility"

No single bug is bizarre. The vulnerability is in **how they compose**.

## Files

```
.
├── app.py                  # Flask app + plugin loader (vulnerable)
├── mqtt_receiver.py        # MQTT subscriber (vulnerable OTA handler)
├── sensor_simulator.py     # Fake ESP8266 (publishes the OTA hint)
├── .env                    # Holds the final flag
├── docker-compose.yml      # Mosquitto broker
├── mosquitto/config/       # Broker config
├── templates/index.html    # Dashboard UI
├── plugins/                # Auto-loaded on startup (RCE landing zone)
│   └── hello.py            # Example plugin
└── firmware/               # Served via HTTP at /firmware/<file>
    └── latest.bin          # Placeholder firmware blob
```
